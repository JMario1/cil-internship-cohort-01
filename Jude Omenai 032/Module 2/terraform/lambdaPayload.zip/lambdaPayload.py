def handler(*args, **kwargs): 
    print("successfully deployed lambda with terraform")
    return 200