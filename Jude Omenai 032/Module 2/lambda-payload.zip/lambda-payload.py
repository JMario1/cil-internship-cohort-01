def handler(*args, **kwargs): 
    print("successfully deployed lambda with ansible")
    return 200